
import { describe, it, expect } from 'vitest';

import { readFileSync } from 'fs';

import { resolve } from 'path';

import { zodToJsonSchema } from 'zod-to-json-schema';

import { ReviewReportSchema } from '../src/types/index.js';

import { withRetry } from '../src/utils/error-handler.js';

const validReport = JSON.parse(

  readFileSync(

    resolve('reports/udacity_cd14715-simple-todo-app_1.json'),

    'utf-8'

  )

);

describe('ReviewReportSchema Validation', () => {

  it('accepts a valid ReviewReport', () => {

    const result = ReviewReportSchema.safeParse(validReport);

    expect(result.success).toBe(true);

  });

  it('rejects invalid data with missing required fields', () => {

    const result = ReviewReportSchema.safeParse({ pullRequest: { owner: 'udacity' } });

    expect(result.success).toBe(false);

  });

  it('handles edge cases with empty arrays', () => {

    const edgeCaseReport = {

      ...validReport,

      fileReviews: [],

      recommendations: [],

    };

    const result = ReviewReportSchema.safeParse(edgeCaseReport);

    expect(result.success).toBe(true);

  });

  it('exports a valid JSON schema for SDK structured outputs', () => {

    const jsonSchema = zodToJsonSchema(ReviewReportSchema as never, {

      $refStrategy: 'root',

    }) as Record<string, unknown>;

    expect(jsonSchema).toBeDefined();

    expect(typeof jsonSchema).toBe('object');

  });

});

describe('Utility Functions', () => {

  it('withRetry retries transient failures and succeeds', async () => {

    let attempts = 0;

    const result = await withRetry(

      async () => {

        attempts += 1;

        if (attempts < 2) throw new Error('Transient failure');

        return 'ok';

      },

      { maxRetries: 3, baseDelayMs: 10 }

    );

    expect(result).toBe('ok');

    expect(attempts).toBe(2);

  });

});

