import { query } from '@anthropic-ai/claude-agent-sdk';
import { zodToJsonSchema } from 'zod-to-json-schema';
import { mcpServersConfig } from './config/mcp.config.js';
import {
 codeQualityAnalyzerAgent,
 testCoverageAnalyzerAgent,
 refactoringSuggesterAgent,
} from './agents/index.js';
import { orchestratorPrompt } from './prompts/index.js';
import { ReviewReportSchema, type ReviewReport } from './types/index.js';
export interface OrchestratorOptions {
 model?: string;
 maxTurns?: number;
}
function asRecord(value: unknown): Record<string, unknown> | undefined {
 if (typeof value === 'object' && value !== null) {
   return value as Record<string, unknown>;
 }
 return undefined;
}
export class CodeReviewOrchestrator {
 private readonly model: string;
 private readonly maxTurns: number;
 constructor(options: OrchestratorOptions = {}) {
   this.model =
     options.model ||
     process.env.ANTHROPIC_MODEL ||
     'claude-sonnet-4-5-20250929';
   this.maxTurns = options.maxTurns ?? 20;
 }
 async reviewPullRequest(
   owner: string,
   repo: string,
   prNumber: number
 ): Promise<ReviewReport> {
   const jsonSchema = zodToJsonSchema(ReviewReportSchema as never, {
     $refStrategy: 'root',
   });
   const outputFormat = {
     type: 'json_schema' as const,
     schema: jsonSchema,
   };
   const userPrompt = `Review pull request #${prNumber} in repository ${owner}/${repo}.
Fetch the PR metadata, description, changed files, and diffs using GitHub MCP tools, invoke the subagents via Task for code quality, test coverage, and refactoring analysis, and return the final structured report matching ReviewReport.`;
   let structuredOutput: unknown;
   console.log(`[Orchestrator] Starting review for ${owner}/${repo}#${prNumber} (model: ${this.model})...`);
   for await (const message of query({
     prompt: userPrompt,
     options: {
       systemPrompt: orchestratorPrompt,
       model: this.model,
       maxTurns: this.maxTurns,
       permissionMode: 'bypassPermissions',
       allowDangerouslySkipPermissions: true,
       mcpServers: mcpServersConfig,
       allowedTools: [
         'Task',
         'Read',
         'Grep',
         'Glob',
         'mcp__github__*',
         'mcp__eslint__*',
       ],
       agents: {
         'code-quality-analyzer': codeQualityAnalyzerAgent,
         'test-coverage-analyzer': testCoverageAnalyzerAgent,
         'refactoring-suggester': refactoringSuggesterAgent,
       },
       outputFormat,
       stderr: (data: string) => {
         const line = data.trim();
         if (line) console.error(`[SDK stderr] ${line}`);
       },
     },
   })) {
     const msg = asRecord(message);
     if (!msg) continue;
     if (msg.type === 'system' && msg.subtype === 'init') {
       console.log('[Orchestrator] MCP servers:', JSON.stringify(msg.mcp_servers));
     } else if (msg.type === 'assistant') {
       console.log('[Orchestrator] Agent step completed...');
     } else if (msg.type === 'result') {
       console.log(`[Orchestrator] Finished with subtype: ${String(msg.subtype ?? 'done')}`);
     }
     if (msg.structured_output !== undefined) {
       structuredOutput = msg.structured_output;
     } else {
       const resultObj = asRecord(msg.result);
       if (resultObj && resultObj.structured_output !== undefined) {
         structuredOutput = resultObj.structured_output;
       }
     }
   }
   const parsed = ReviewReportSchema.safeParse(structuredOutput);
   if (!parsed.success) {
     throw new Error(
       `Failed to validate ReviewReport output: ${parsed.error.message}`
     );
   }
   return parsed.data;
 }
}
export { CodeReviewOrchestrator as Orchestrator };
