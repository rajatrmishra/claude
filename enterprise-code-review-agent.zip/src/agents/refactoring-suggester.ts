import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { refactoringSuggesterPrompt } from '../prompts/refactoring-suggester.prompt.js';
export const refactoringSuggesterAgent: AgentDefinition = {
 description:
   'Identifies opportunities to improve code structure, apply design patterns, modernize language usage, and remove dead or redundant logic with actionable refactoring examples.',
 model: 'inherit',
 tools: ['Read', 'Grep', 'Glob', 'Skill'],
 prompt: refactoringSuggesterPrompt,
};
