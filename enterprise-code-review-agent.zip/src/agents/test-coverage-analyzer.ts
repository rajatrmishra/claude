import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { testCoverageAnalyzerPrompt } from '../prompts/test-coverage-analyzer.prompt.js';
export const testCoverageAnalyzerAgent: AgentDefinition = {
 description:
   'Evaluates test coverage across changed and related source/test files, identifies untested functions and edge cases, estimates coverage, and recommends concrete test cases with assertions.',
 model: 'inherit',
 tools: ['Read', 'Grep', 'Glob', 'Skill'],
 prompt: testCoverageAnalyzerPrompt,
};
