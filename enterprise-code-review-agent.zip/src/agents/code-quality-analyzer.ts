import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { codeQualityAnalyzerPrompt } from '../prompts/code-quality-analyzer.prompt.js';
export const codeQualityAnalyzerAgent: AgentDefinition = {
 description:
   'Analyzes code changes for security vulnerabilities, performance bottlenecks, maintainability issues, and ESLint/best-practice violations. Use when reviewing code quality or invoking code-review-best-practices skills.',
 model: 'inherit',
 tools: ['Read', 'Grep', 'Glob', 'Skill'],
 prompt: codeQualityAnalyzerPrompt,
};
