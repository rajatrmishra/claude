import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import * as dotenv from 'dotenv';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator, formatError } from './utils/index.js';
dotenv.config();
function validateArgs(
 owner: string | undefined,
 repo: string | undefined,
 prStr: string | undefined
): { owner: string; repo: string; prNumber: number } {
 if (!owner || !repo || !prStr) {
   console.error('Usage: npm run dev <owner> <repo> <pr-number>');
   console.error('Example: npm run dev udacity cd14715-simple-todo-app 1');
   process.exit(1);
 }
 const prNumber = Number(prStr);
 if (!Number.isInteger(prNumber) || prNumber <= 0 || String(prNumber) !== prStr.trim()) {
   console.error(`Invalid PR number "${prStr}". Must be a positive integer.`);
   process.exit(1);
 }
 return { owner, repo, prNumber };
}
function validateEnvironment(): void {
 const hasAnthropicKey = Boolean(process.env.ANTHROPIC_API_KEY?.trim());
 const hasAwsKeys = Boolean(
   process.env.AWS_ACCESS_KEY_ID?.trim() && process.env.AWS_SECRET_ACCESS_KEY?.trim()
 );
 if (hasAwsKeys) {
   if (!process.env.AWS_REGION?.trim()) {
     console.error('AWS_REGION is required when using AWS Bedrock credentials.');
     process.exit(1);
   }
   console.log('Using AWS Bedrock authentication');
 } else if (hasAnthropicKey) {
   console.log('Using Anthropic API authentication');
 } else {
   console.error('Missing authentication credentials.');
   console.error('Set ANTHROPIC_API_KEY for Anthropic API, OR set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (plus AWS_REGION) for AWS Bedrock.');
   process.exit(1);
 }
 if (!process.env.ANTHROPIC_MODEL?.trim()) {
   console.error('ANTHROPIC_MODEL environment variable is required.');
   console.error('Example (Anthropic API): claude-sonnet-4-5-20250929');
   console.error('Example (AWS Bedrock): us.anthropic.claude-sonnet-4-5-20250929-v1:0');
   process.exit(1);
 }
}
async function main(): Promise<void> {
 const [ownerArg, repoArg, prStr] = process.argv.slice(2);
 const { owner, repo, prNumber } = validateArgs(ownerArg, repoArg, prStr);
 validateEnvironment();
 try {
   const orchestrator = new CodeReviewOrchestrator();
   const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);
   const generator = new ReportGenerator();
   const jsonContent = generator.generateJSONReport(report);
   const mdContent = generator.generateMarkdownReport(report);
   const htmlContent = generator.generateHTMLReport(report);
   const reportsDir = path.resolve(process.cwd(), 'reports');
   await fs.mkdir(reportsDir, { recursive: true });
   const baseName = `${owner}_${repo}_${prNumber}`;
   const jsonPath = path.join(reportsDir, `${baseName}.json`);
   const mdPath = path.join(reportsDir, `${baseName}.md`);
   const htmlPath = path.join(reportsDir, `${baseName}.html`);
   await Promise.all([
     fs.writeFile(jsonPath, jsonContent, 'utf-8'),
     fs.writeFile(mdPath, mdContent, 'utf-8'),
     fs.writeFile(htmlPath, htmlContent, 'utf-8'),
   ]);
   console.log('Reports generated successfully:');
   console.log(`- JSON: ${jsonPath}`);
   console.log(`- Markdown: ${mdPath}`);
   console.log(`- HTML: ${htmlPath}`);
 } catch (error) {
   console.error(`Review failed: ${formatError(error)}`);
   process.exit(1);
 }
}
main();
