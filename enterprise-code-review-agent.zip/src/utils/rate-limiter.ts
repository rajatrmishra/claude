
export interface RateLimiterConfig {

  maxConcurrent?: number;

  maxRequestsPerMinute?: number;

  maxTokensPerMinute?: number;

  windowMs?: number;

}

interface RequestRecord {

  timestamp: number;

  tokens: number;

}

export class RateLimiter {

  private readonly maxConcurrent: number;

  private readonly maxRequestsPerMinute: number;

  private readonly maxTokensPerMinute: number;

  private readonly windowMs: number;

  private activeRequests = 0;

  private requestHistory: RequestRecord[] = [];

  private waitQueue: Array<() => void> = [];

  constructor(config: RateLimiterConfig = {}) {

    this.maxConcurrent = config.maxConcurrent ?? 3;

    this.maxRequestsPerMinute = config.maxRequestsPerMinute ?? 30;

    this.maxTokensPerMinute = config.maxTokensPerMinute ?? 100000;

    this.windowMs = config.windowMs ?? 60_000;

  }

  pruneOldRecords(now: number = Date.now()): void {

    const cutoff = now - this.windowMs;

    this.requestHistory = this.requestHistory.filter(

      (record) => record.timestamp > cutoff

    );

  }

  canProceed(estimatedTokens: number = 0, now: number = Date.now()): boolean {

    this.pruneOldRecords(now);

    if (this.activeRequests >= this.maxConcurrent) {

      return false;

    }

    const recentRequests = this.requestHistory.length;

    if (recentRequests + 1 > this.maxRequestsPerMinute) {

      return false;

    }

    const recentTokens = this.requestHistory.reduce(

      (sum, record) => sum + record.tokens,

      0

    );

    if (recentTokens + estimatedTokens > this.maxTokensPerMinute) {

      return false;

    }

    return true;

  }

  async waitForSlot(): Promise<void> {

    if (this.activeRequests < this.maxConcurrent) {

      return;

    }

    await new Promise<void>((resolve) => {

      this.waitQueue.push(resolve);

    });

  }

  async waitForRateLimit(estimatedTokens: number = 0): Promise<void> {

    while (!this.canProceed(estimatedTokens)) {

      const now = Date.now();

      this.pruneOldRecords(now);

      const oldest = this.requestHistory[0];

      const waitMs = oldest

        ? Math.max(50, oldest.timestamp + this.windowMs - now + 10)

        : 100;

      await new Promise<void>((resolve) => setTimeout(resolve, waitMs));

    }

  }

  async acquire(estimatedTokens: number = 1000): Promise<void> {

    await this.waitForSlot();

    await this.waitForRateLimit(estimatedTokens);

    this.activeRequests += 1;

    this.requestHistory.push({

      timestamp: Date.now(),

      tokens: estimatedTokens,

    });

  }

  release(): void {

    if (this.activeRequests > 0) {

      this.activeRequests -= 1;

    }

    const next = this.waitQueue.shift();

    if (next) {

      next();

    }

  }

}

export async function withRateLimit<T>(

  rateLimiter: RateLimiter,

  fn: () => Promise<T>,

  estimatedTokens: number = 1000

): Promise<T> {

  await rateLimiter.acquire(estimatedTokens);

  try {

    return await fn();

  } finally {

    rateLimiter.release();

  }

}

export const globalRateLimiter = new RateLimiter();

