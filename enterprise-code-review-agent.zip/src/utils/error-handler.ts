
export enum ErrorCodes {

  RETRY_EXHAUSTED = 'RETRY_EXHAUSTED',

  TIMEOUT = 'TIMEOUT',

  VALIDATION_ERROR = 'VALIDATION_ERROR',

  MCP_ERROR = 'MCP_ERROR',

  API_ERROR = 'API_ERROR',

  UNKNOWN_ERROR = 'UNKNOWN_ERROR',

}

export class ReviewError extends Error {

  public readonly code: ErrorCodes;

  public readonly cause?: unknown;

  constructor(message: string, code: ErrorCodes = ErrorCodes.UNKNOWN_ERROR, cause?: unknown) {

    super(message);

    this.name = 'ReviewError';

    this.code = code;

    this.cause = cause;

  }

}

export function isReviewError(error: unknown): error is ReviewError {

  return error instanceof ReviewError;

}

export function formatError(error: unknown): string {

  if (isReviewError(error)) {

    return `[${error.code}] ${error.message}`;

  }

  if (error instanceof Error) {

    return error.message;

  }

  return String(error);

}

export interface RetryOptions {

  maxRetries?: number;

  baseDelayMs?: number;

}

export async function withRetry<T>(

  fn: () => Promise<T>,

  options: RetryOptions = {}

): Promise<T> {

  const maxRetries = options.maxRetries ?? 3;

  const baseDelayMs = options.baseDelayMs ?? 1000;

  let lastError: unknown;

  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {

    try {

      return await fn();

    } catch (error) {

      lastError = error;

      if (attempt > maxRetries) {

        break;

      }

      const exponentialMs = baseDelayMs * Math.pow(2, attempt - 1);

      const jitterMs = Math.floor(Math.random() * 101);

      const delayMs = exponentialMs + jitterMs;

      await new Promise<void>((resolve) => setTimeout(resolve, delayMs));

    }

  }

  throw new ReviewError(

    `Operation failed after ${maxRetries + 1} attempts: ${formatError(lastError)}`,

    ErrorCodes.RETRY_EXHAUSTED,

    lastError

  );

}

export async function withTimeout<T>(

  fn: () => Promise<T>,

  timeoutMs: number

): Promise<T> {

  let timer: ReturnType<typeof setTimeout> | undefined;

  const timeoutPromise = new Promise<never>((_, reject) => {

    timer = setTimeout(() => {

      reject(

        new ReviewError(

          `Operation timed out after ${timeoutMs}ms`,

          ErrorCodes.TIMEOUT

        )

      );

    }, timeoutMs);

  });

  try {

    return await Promise.race([fn(), timeoutPromise]);

  } finally {

    if (timer !== undefined) {

      clearTimeout(timer);

    }

  }

}

