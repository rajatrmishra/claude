# Reflection Brief — Evaluation and Observability Capstone

**Name:** Rajat Ranjan Mishra
**Date:** 2026-11-20

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Linux 6.6.97+ x86_64 GNU/Linux |
| Python version | Python 3.13.0 |
| Date run | 2026-11-20 |
| Ran any system live? (which) | No (all systems run offline / replay mode) |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | 45 passed, 3 skipped (`01-policy-pipeline/tests.txt`) |
| Routing output file | `01-policy-pipeline/pipeline-run.txt` (offline fallback: `tests/test_us04_routing.py`) |
| auto_approve / human_review / spot_check counts | Verified via offline routing suite (`test_us04_routing.py`) |

**1a. Retry boundary.**
> In `01-policy-pipeline/perturbation-retry.txt` (`tests/test_us01_retry.py`), when a required field is genuinely absent (`null`), the system escalates after **1 API call**. Retrying a futile case is worse than escalating because the information does not exist in the source document—extra retries waste latency/tokens and pressure the model into fabricating a value to satisfy the schema.

**1b. Reading the router.**
> In `01-policy-pipeline/pipeline-run.txt`, `test_ac_04_06_high_confidence_plus_reviewer_disagreement_still_routes_to_human_review` routes a record to `human_review` driven by the **reviewer** signal (independent reviewer disagreement). If we had trusted the extractor's confidence score alone, a high-confidence but erroneous extraction would have been silently auto-approved.

**1c. Where the aggregate lies.**
> In `01-policy-pipeline/calibration-report.txt`, the `umbrella / exclusions` cell reports `acc=0.00` despite `conf=0.93`, while the overall figure stays moderate (`OVERALL brier=0.291`). Slicing by `policy_type × field` exposes severe localized overconfidence on a specific risk-heavy field that a single aggregate Brier score masks.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | 25 passed in 1.76s (`02-mortgage-extraction/tests.txt`) |
| Document run | `appraisal_informal_sqft.txt`, `income_missing_bonus.txt`, `income_sum_mismatch.txt` |
| Classified type | `appraisal` / `income` (`02-mortgage-extraction/extract-run.txt`) |

**2a. Two guarantees.**
> From `02-mortgage-extraction/discrepancy-run.txt` (`income_sum_mismatch.txt`):
> `"validation": { "consistent": false, "discrepancies": [{ "field": "total_monthly_income", "calculated": 9642.17, "stated": 10892.17, "delta": -1250.0 }] }`
> Tool use enforces **structural/syntactic** validity (valid JSON, expected keys and types), while the validator enforces **semantic/arithmetic** consistency across fields. Tool use cannot catch a stated total that disagrees with the sum of its line items; the arithmetic validator cannot prevent malformed JSON or wrong data types.

**2b. Refusing to fabricate.**
> In `02-mortgage-extraction/extract-run.txt` (`income_missing_bonus.txt`) and `discrepancy-run.txt`, absent fields return `"bonus_ytd": null` rather than an invented number. Returning `null` prevents hallucinated income from corrupting underwriting decisions; this is enabled in the schema by defining optional/nullable field types so missing values remain valid without forcing a guess.

**2c. Normalization.**
> In `02-mortgage-extraction/extract-run.txt` (`appraisal_informal_sqft.txt`), informal source text (`"about 2,400 sq ft"`) is normalized to the integer `2400`. Normalizing at extraction time establishes a single, typed data contract so downstream validators, databases, and calculators do not each have to re-implement fragile string parsing.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | 34 passed in 47.33s (`03-supply-chain/tests.txt`) |
| Briefing file | `03-supply-chain/briefing.md` (and `investigation-run.txt`) |
| Section the conflict landed in | `## Contested` |

**3a. Annotate, don't arbitrate.**
> From `03-supply-chain/briefing.md` (`## Contested` -> `### on_time_delivery_rate`):
> `- 95.0 percent — supplier_audit (as of 2026-04-10)`
> `- 78.0 percent — Logistics (as of 2026-04-05)`
> Preserving both values with source and date lets a human decision-maker see the 17-point gap and weigh internal logistics telemetry against a self-reported audit, rather than acting on an opaque, averaged number that hides the risk.

**3b. Source goes dark.**
> From `03-supply-chain/timeout-run.txt` (`## Incomplete`):
> `### late_shipment_count _[missing source: timeout reading Logistics]_`
> `- missing source: timeout reading Logistics`
> An unreachable source is explicitly tagged as a timeout failure rather than silently treated as "nothing to report" (which would falsely imply zero late shipments). The run still finishes so valid findings from surviving sources (`port_disruption`, `supplier_financial_distress`) are delivered without blocking on one failed dependency.

**3c. Dates as a guardrail.**
> From `03-supply-chain/briefing.md`: `port_disruption` (`industry_news, 2026-03-17`) and `supplier_financial_distress` (`industry_news, 2026-03-09`), as well as `on_time_delivery_rate` (`supplier_audit, 2026-04-10` vs. `Logistics, 2026-04-05`). Requiring dates prevents a legitimate change over time from being misread as a simultaneous contradiction between sources.

---

## 4. Synthesis

**4a. One principle.**
> **System 2 (`02-mortgage-extraction/discrepancy-run.txt`):** The extraction produced clean, schema-valid JSON with `"stated_monthly_total": 10892.17`, which a trusting pipeline would have shipped straight to underwriting. The deterministic arithmetic validator caught that the line items only summed to `9642.17` (`delta: -1250.0`).

**4b. Confidence ≠ correctness.**
> **System 1 (`01-policy-pipeline/calibration-report.txt` & `pipeline-run.txt`):** The `umbrella / exclusions` slice had `conf=0.93` with `acc=0.00`, and `test_ac_04_06_high_confidence_plus_reviewer_disagreement_still_routes_to_human_review` proved that a high-confidence extraction can still be wrong—making independent review and sliced calibration mandatory.

**4c. Apply it.**
> In an automated vendor invoice / purchase-order ingestion workflow (extracting line items, taxes, and totals from messy PDFs), I would reach first for **schema-enforced extraction with deterministic cross-field validation and validated retry/escalation**. I would instrument three metrics: arithmetic validation-failure rate, sliced calibration error by vendor/document type, and single-call escalation rate for missing required fields.
