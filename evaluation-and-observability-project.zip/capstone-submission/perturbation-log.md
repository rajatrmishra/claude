# Perturbation Log

## System 1 — Policy Pipeline
- **Perturbation:** Triggered the missing required field (`null`) escalation path via the retry test suite.
- **Command run:** `.venv/bin/pytest tests/test_us01_retry.py -v` (captured in `01-policy-pipeline/perturbation-retry.txt`)
- **Observed result:** When a required field is genuinely absent (`null`), the pipeline escalates immediately after **1 API call** without inventing a value.
- **Contrast with unperturbed input:** On a valid, complete policy document, extraction succeeds without escalation and proceeds to independent review and routing.

## System 2 — Mortgage Document Extraction
- **Perturbation:** Ran extraction on an income document with a line-item sum mismatch (`income_sum_mismatch.txt`) instead of a clean document (`appraisal_informal_sqft.txt`).
- **Command run:** `.venv/bin/mortgage-extract fixtures/documents/income_sum_mismatch.txt --mode replay` (captured in `02-mortgage-extraction/discrepancy-run.txt`)
- **Observed result:** Extraction returned valid JSON, and the consistency validator flagged `"consistent": false` on `total_monthly_income` (`calculated: 9642.17`, `stated: 10892.17`, `delta: -1250.0`).
- **Contrast with unperturbed input:** On `appraisal_informal_sqft.txt` (`02-mortgage-extraction/extract-run.txt`), extraction normalizes `"about 2,400 sq ft"` to `2400` and passes validation with zero discrepancies.

## System 3 — Supply Chain Risk Investigation
- **Perturbation:** Forced a source timeout on the Logistics reader using `--simulate-timeout`.
- **Command run:** `.venv/bin/supply-chain-investigate meridian --offline --simulate-timeout` (captured in `03-supply-chain/timeout-run.txt`)
- **Observed result:** The run completed gracefully instead of aborting, annotating `late_shipment_count` under `## Incomplete` with `missing source: timeout reading Logistics`, while preserving findings from surviving sources.
- **Contrast with unperturbed input:** Without `--simulate-timeout` (`03-supply-chain/investigation-run.txt` / `briefing.md`), the Logistics source succeeds, reporting `11.0 shipments` for `late_shipment_count` and surfacing the `on_time_delivery_rate` conflict (`95.0 percent` vs. `78.0 percent`) under `## Contested`.
